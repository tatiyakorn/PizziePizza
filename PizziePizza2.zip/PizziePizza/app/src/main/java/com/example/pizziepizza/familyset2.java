package com.example.pizziepizza;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class familyset2 extends Fragment {
    private Button MinusButton;
    private Button PlusButton;
    private TextView orderbeefpizza;
    private TextView orderbeefpasta;
    private TextView ordergrilledchicken_S;
    private int counterbeefpasta;
    private int counterbeefpizza;
    private int countergrilledchicken_S;

    //beef
    private View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusbeefpizza:
                    Minusbeefpizza();
                    break;
                case R.id.Plusbeefpizza:
                    Plusbeefpizza();
                    break;
            }
        }
    };
    //beefpasta
    private View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusbeefpasta:
                    Minusbeefpasta();
                    break;
                case R.id.Plusbeefpasta:
                    Plusbeefpasta();
                    break;
            }
        }
    };
    //grilledchicken_S
    private View.OnClickListener clickListener3 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusgrilledchicken_S:
                    Minusgrilledchicken_S();
                    break;
                case R.id.Plusgrilledchicken_S:
                    Plusgrilledchicken_S();
                    break;
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_familyset2, container, false);

        //beef
        orderbeefpizza = (TextView) view.findViewById(R.id.orderbeefpizza);
        MinusButton = (Button) view.findViewById(R.id.Minusbeefpizza);
        MinusButton.setOnClickListener(clickListener1);
        PlusButton = (Button) view.findViewById(R.id.Plusbeefpizza);
        PlusButton.setOnClickListener(clickListener1);
        initCounter1();

        //beefpasta
        orderbeefpasta = (TextView) view.findViewById(R.id.orderbeefpasta);
        MinusButton = (Button) view.findViewById(R.id.Minusbeefpasta);
        MinusButton.setOnClickListener(clickListener2);
        PlusButton = (Button) view.findViewById(R.id.Plusbeefpasta);
        PlusButton.setOnClickListener(clickListener2);
        initCounter2();

        //grilledchicken_S
        ordergrilledchicken_S = (TextView) view.findViewById(R.id.ordergrilledchicken_S);
        MinusButton = (Button) view.findViewById(R.id.Minusgrilledchicken_S);
        MinusButton.setOnClickListener(clickListener3);
        PlusButton = (Button) view.findViewById(R.id.Plusgrilledchicken_S);
        PlusButton.setOnClickListener(clickListener3);
        initCounter3();
        return view;

    }





    //beef
    private void initCounter1(){
        counterbeefpizza=0;
        orderbeefpizza.setText(counterbeefpizza + "");
    }
    private void Plusbeefpizza(){
        counterbeefpizza++;
        orderbeefpizza.setText(counterbeefpizza + "");
    }
    private void Minusbeefpizza(){
        counterbeefpizza--;
        orderbeefpizza.setText(counterbeefpizza + "");
    }
    //beefpasta
    private void initCounter2(){
        counterbeefpasta=0;
        orderbeefpasta.setText(counterbeefpasta + "");
    }
    private void Plusbeefpasta(){
        counterbeefpasta++;
        orderbeefpasta.setText(counterbeefpasta + "");
    }
    private void Minusbeefpasta(){
        counterbeefpasta--;
        orderbeefpasta.setText(counterbeefpasta + "");
    }
    //grilledchicken_S
    private void initCounter3(){
        countergrilledchicken_S=0;
        ordergrilledchicken_S.setText(countergrilledchicken_S + "");
    }
    private void Plusgrilledchicken_S(){
        countergrilledchicken_S++;
        ordergrilledchicken_S.setText(countergrilledchicken_S + "");
    }
    private void Minusgrilledchicken_S(){
        countergrilledchicken_S--;
        ordergrilledchicken_S.setText(countergrilledchicken_S + "");
    }
}

