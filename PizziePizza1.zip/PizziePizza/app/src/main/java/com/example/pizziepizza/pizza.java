package com.example.pizziepizza;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class pizza  {
    private Button MinusButton;
    private Button PlusButton;
    private TextView orderbeefpizza;
    private TextView orderbbqpizza;
    private TextView ordercornpizza;
    private TextView ordertunapizza;
    private int counterbeefpizza;
    private int counterbbqpizza;
    private int countercornpizza;
    private int countertunapizza;

    //beef
    private View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusbeefpizza:
                    Minusbeefpizza();
                    break;
                case R.id.Plusbeefpizza:
                    Plusbeefpizza();
                    break;
            }
        }
    };
    //bbq
    private View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusbbqpizza:
                    Minusbbqpizza();
                    break;
                case R.id.Plusbbqpizza:
                    Plusbbqpizzae();
                    break;
            }
        }
    };
    //corn
    private View.OnClickListener clickListener3 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minuscornpizza:
                    Minuscornpizzan();
                    break;
                case R.id.Pluscornpizza:
                    Pluscornpizza();
                    break;
            }
        }
    };
    //tuna
    private View.OnClickListener clickListener4 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minustunapizza:
                    Minustropicalseafood();
                    break;
                case R.id.Plustunapizza:
                    Plustropicalseafood();
                    break;
            }
        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_pizza);

        //beef
        orderbeefpizza = (TextView) findViewById(R.id.orderbeefpizza);
        MinusButton = (Button) findViewById(R.id.Minusbeefpizza);
        MinusButton.setOnClickListener(clickListener1);
        PlusButton = (Button) findViewById(R.id.Plusbeefpizza);
        PlusButton.setOnClickListener(clickListener1);
        initCounter1();
        //bbq
        orderbbqpizza = (TextView) findViewById(R.id.orderbbqpizza);
        MinusButton = (Button) findViewById(R.id.Minusbbqpizza);
        MinusButton.setOnClickListener(clickListener2);
        PlusButton = (Button) findViewById(R.id.Plusbbqpizza);
        PlusButton.setOnClickListener(clickListener2);
        initCounter2();
        //corn
        ordercornpizza = (TextView) findViewById(R.id.ordercornpizza);
        MinusButton = (Button) findViewById(R.id.Minuscornpizza);
        MinusButton.setOnClickListener(clickListener3);
        PlusButton = (Button) findViewById(R.id.Pluscornpizza);
        PlusButton.setOnClickListener(clickListener3);
        initCounter3();
        //tuna
        ordertunapizza = (TextView) findViewById(R.id.ordertunapizza);
        MinusButton = (Button) findViewById(R.id.Minustunapizza);
        MinusButton.setOnClickListener(clickListener4);
        PlusButton = (Button) findViewById(R.id.Plustunapizza);
        PlusButton.setOnClickListener(clickListener4);
        initCounter4();






        //Initialize And Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        //Set Home Selected
        bottomNavigationView.setSelectedItemId(R.id.home);
        //Perform ItemSelectedListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        return true;
                    case R.id.order:
                        startActivity(new Intent(getApplicationContext()
                                , Order.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.history:
                        startActivity(new Intent(getApplicationContext()
                                , History.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext()
                                , Login.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
    }
    //beef
    private void initCounter1(){
        counterbeefpizza=0;
        orderbeefpizza.setText(counterbeefpizza + "");
    }
    private void Plusbeefpizza(){
        counterbeefpizza++;
        orderbeefpizza.setText(counterbeefpizza + "");
    }
    private void Minusbeefpizza(){
        counterbeefpizza--;
        orderbeefpizza.setText(counterbeefpizza + "");
    }
    //bbq
    private void initCounter2(){
        counterbbqpizza=0;
        orderbbqpizza.setText(counterbbqpizza + "");
    }
    private void Plusbbqpizzae(){
        counterbbqpizza++;
        orderbbqpizza.setText(counterbbqpizza+ "");
    }
    private void Minusbbqpizza(){
        counterbbqpizza--;
        orderbbqpizza.setText(counterbbqpizza + "");
    }
    //corn
    private void initCounter3(){
        countercornpizza=0;
        ordercornpizza.setText(countercornpizza + "");
    }
    private void Pluscornpizza(){
        countercornpizza++;
        ordercornpizza.setText(countercornpizza + "");
    }
    private void Minuscornpizzan(){
        countercornpizza--;
        ordercornpizza.setText(countercornpizza + "");
    }
    //tuna
    private void initCounter4(){
        countertunapizza=0;
        ordertunapizza.setText(countertunapizza+ "");
    }
    private void Plustropicalseafood(){
        countertunapizza++;
        ordertunapizza.setText(countertunapizza + "");
    }
    private void Minustropicalseafood(){
        countertunapizza--;
        ordertunapizza.setText(countertunapizza + "");
    }
}

