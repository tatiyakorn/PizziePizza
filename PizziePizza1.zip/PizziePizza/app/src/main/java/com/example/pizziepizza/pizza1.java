package com.example.pizziepizza;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class pizza extends AppCompatActivity {
    private Button MinusButton;
    private Button PlusButton;
    private TextView orderbacon;
    private TextView orderbbq;
    private TextView orderhawaiian;
    private TextView ordertropical;
    private int counterbacon;
    private int counterbbq;
    private int counterhawaiian;
    private int countertropical;

    //bacon
    private View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusbaconsuperdelight:
                    Minusbaconsuperdelight();
                    break;
                case R.id.Plusbaconsuperdelight:
                    Plusbaconsuperdelight();
                    break;
            }
        }
    };
    //bbq
    private View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minusbbqchickendeluxe:
                    Minusbbqchickendeluxe();
                    break;
                case R.id.Plusbbqchickendeluxe:
                    Plusbbqchickendeluxe();
                    break;
            }
        }
    };
    //hawaiian
    private View.OnClickListener clickListener3 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minushawaiian:
                    Minushawaiian();
                    break;
                case R.id.Plushawaiian:
                    Plushawaiian();
                    break;
            }
        }
    };
    //tropical
    private View.OnClickListener clickListener4 = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Minustropicalseafood:
                    Minustropicalseafood();
                    break;
                case R.id.Plustropicalseafood:
                    Plustropicalseafood();
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza);

        //bacon
        orderbacon = (TextView) findViewById(R.id.orderbaconsuperdelight);
        MinusButton = (Button) findViewById(R.id.Minusbaconsuperdelight);
        MinusButton.setOnClickListener(clickListener1);
        PlusButton = (Button) findViewById(R.id.Plusbaconsuperdelight);
        PlusButton.setOnClickListener(clickListener1);
        initCounter1();
        //bbq
        orderbbq = (TextView) findViewById(R.id.orderbbqchickendeluxe);
        MinusButton = (Button) findViewById(R.id.Minusbbqchickendeluxe);
        MinusButton.setOnClickListener(clickListener2);
        PlusButton = (Button) findViewById(R.id.Plusbbqchickendeluxe);
        PlusButton.setOnClickListener(clickListener2);
        initCounter2();
        //hawaiian
        orderhawaiian = (TextView) findViewById(R.id.orderhawaiian);
        MinusButton = (Button) findViewById(R.id.Minushawaiian);
        MinusButton.setOnClickListener(clickListener3);
        PlusButton = (Button) findViewById(R.id.Plushawaiian);
        PlusButton.setOnClickListener(clickListener3);
        initCounter3();
        //tropical
        ordertropical = (TextView) findViewById(R.id.ordertropicalseafood);
        MinusButton = (Button) findViewById(R.id.Minustropicalseafood);
        MinusButton.setOnClickListener(clickListener4);
        PlusButton = (Button) findViewById(R.id.Plustropicalseafood);
        PlusButton.setOnClickListener(clickListener4);
        initCounter4();






        //Initialize And Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        //Set Home Selected
        bottomNavigationView.setSelectedItemId(R.id.home);
        //Perform ItemSelectedListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        return true;
                    case R.id.order:
                        startActivity(new Intent(getApplicationContext()
                                , Order.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.history:
                        startActivity(new Intent(getApplicationContext()
                                , History.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext()
                                , Login.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
    }
    //bacon
    private void initCounter1(){
        counterbacon=0;
        orderbacon.setText(counterbacon + "");
    }
    private void Plusbaconsuperdelight(){
        counterbacon++;
        orderbacon.setText(counterbacon + "");
    }
    private void Minusbaconsuperdelight(){
        counterbacon--;
        orderbacon.setText(counterbacon + "");
    }
    //bbq
    private void initCounter2(){
        counterbbq=0;
        orderbbq.setText(counterbbq + "");
    }
    private void Plusbbqchickendeluxe(){
        counterbbq++;
        orderbbq.setText(counterbbq+ "");
    }
    private void Minusbbqchickendeluxe(){
        counterbbq--;
        orderbbq.setText(counterbbq + "");
    }
    //hawaiian
    private void initCounter3(){
        counterhawaiian=0;
        orderhawaiian.setText(counterhawaiian + "");
    }
    private void Plushawaiian(){
        counterhawaiian++;
        orderhawaiian.setText(counterhawaiian + "");
    }
    private void Minushawaiian(){
        counterhawaiian--;
        orderhawaiian.setText(counterhawaiian + "");
    }
    //tropical
    private void initCounter4(){
        countertropical=0;
        ordertropical.setText(countertropical + "");
    }
    private void Plustropicalseafood(){
        countertropical++;
        ordertropical.setText(countertropical + "");
    }
    private void Minustropicalseafood(){
        countertropical--;
        ordertropical.setText(countertropical + "");
    }
}
